package bingo;

import java.net.*;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.*;
import java.util.Scanner;




public class TcpIpMultichatClient {
	static DataOutputStream out;
	static Label stlb = new Label();
	static Button b = new Button(" �� ��");
	static Socket socket; 
	public static void main(String args[]) {
		
		
		if(args.length!=1) {
			System.out.println("USAGE: java TcpIpMultichatClient ��ȭ��");
			System.exit(0);
		}
		
		Frame f = new Frame("Login");
		f.setSize(400, 400);
		f.setLayout(null); // . ���̾ƿ� �Ŵ����� ������ �����Ѵ�


		b.setSize(100, 50); // Button . �� ũ�⸦ �����Ѵ�
		b.setLocation(150, 150); // Frame Button . �������� �� ��ġ�� �����Ѵ�
		f.add(b);
				


		stlb.setLocation(100,150);
		stlb.setBounds(100, 50, 100, 100); 
		stlb.setText("0");

		f.add(stlb);
		
		f.setVisible(true);

	
		try {
            // ������ �����Ͽ� ������ ��û�Ѵ�.
			socket = new Socket("10.10.10.141", 7777);
			System.out.println("������ ����Ǿ����ϴ�.");
			Thread sender   = new Thread(new ClientSender(socket, args[0]));
			Thread receiver = new Thread(new ClientReceiver(socket));

			sender.start();
			receiver.start();
		} catch(ConnectException ce) {
			ce.printStackTrace();
		} catch(Exception e) {}
		
		
		
		TcpIpMultichatClient awtControlDemo = new TcpIpMultichatClient();
		awtControlDemo.showButton();
	} // main
	

	private void showButton() {
		 b.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	try {
						out.writeUTF("1|���ӽ���");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	            }
	        });


	}


	static class ClientSender extends Thread {
		Socket socket;
	
		String name;

		ClientSender(Socket socket, String name) {
			this.socket = socket;
			try {
				out = new DataOutputStream(socket.getOutputStream());
				this.name = name;
			} catch(Exception e) {}
		}

		public void run() {
			Scanner scanner = new Scanner(System.in);
			try {
				if(out!=null) {
					out.writeUTF(name);
				}	

				while(out!=null) {
					out.writeUTF("["+name+"]"+scanner.nextLine());					}
			} catch(IOException e) {}
		} // run()
	} // ClientSender

	static class ClientReceiver extends Thread {
		Socket socket;
		DataInputStream in;
	
		ClientReceiver(Socket socket) {
			this.socket = socket;
			try {
				in = new DataInputStream(socket.getInputStream());
			} catch(IOException e) {}
		}

		public void run() {
			while(in!=null) {
				try {
					
					String msg = in.readUTF();// msg: ������ ���� �޽���
					//System.out.println(msg);
					// msg==> "300|�ȳ��ϼ���" "160|�ڹٹ�--1,����Ŭ��--1,JDBC��--1"

					String msgs[] = msg.split("\\|");

					String protocol = msgs[0];

					switch (protocol) {
				
					case "100":
						stlb.setText("����� = " + msgs[1]);
						System.out.println(msgs[1]);
						break;
					case "1":
						Bingo win = new Bingo("Bingo Game Ver1.0",socket);
						break;
					}
				}
				catch(IOException e) {}
			}
		} // run
	} // ClientReceiver
} // class